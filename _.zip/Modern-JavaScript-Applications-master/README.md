## $5 Tech Unlocked 2021!
[Buy and download this Book for only $5 on PacktPub.com](https://www.packtpub.com/product/modern-javascript-applications/9781785881442)
-----
*If you have read this book, please leave a review on [Amazon.com](https://www.amazon.com/gp/product/1785881442).     Potential readers can then use your unbiased opinion to help them make purchase decisions. Thank you. The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Modern JavaScript Applications
By PacktPublishing

This is the code repository for [Modern JavaScript Applications](https://www.packtpub.com/web-development/modern-javascript-applications?utm_source=GitHub&utm_medium=Repository&utm_campaign=9781785881442), published by [Packt Publishing](https://www.packtpub.com/). It contains all the required files to run the code.

##What you need
You can use any operating system that supports Node.js and MongoDB. You will
need a browser, but I would recommended you to use the latest version of Chrome
as it's way ahead with supporting the new technologies that are covered in this book.
You will also need a webcam and microphone. And finally, you will need a working
Internet connection.

##Related Books

* [Mastering JavaScript Design Patterns](https://www.packtpub.com/application-development/mastering-javascript-design-patterns?utm_source=GitHub&utm_medium=Repository&utm_campaign=9781783987986)
* [Learning JavaScriptMVC](https://www.packtpub.com/web-development/learning-javascriptmvc?utm_source=GitHub&utm_medium=Repository&utm_campaign=9781782160205)

